import { StyleSheet } from 'react-native';

const appStyles = StyleSheet.create({
  headerStyle: {
    backgroundColor: '#d2691e',
   // backgroundColor: 'white'
  },
  headerTitleStyle: {
    fontWeight: 'bold',
    //justifyContent:'center',
    color: 'white'
  },
});

export default appStyles;
