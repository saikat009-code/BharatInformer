import React, { useState } from 'react';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import appStyles from './AppNavigator.style';
import LoginScreen from '../../screens/login/login.screen';
import RegisterScreen from '../../screens/register/register.screen';
import HomeScreen from '../../screens/home/home.screen';
import { Animated, TextInput, TouchableOpacity, View } from 'react-native';
import { faSearch, faBars } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import SideBarModal from '../../component/modal/SidebarModal';


const Stack = createStackNavigator();

const AppNavigator = () => {

  const [modalVisible, setModalVisible] = useState(false);
  const openModal = () => {
    setModalVisible(true); // Update the state to make the modal visible
  };

  const closeModal = () => {
    setModalVisible(false);
  };

  return (
    <NavigationContainer>
       
      <Stack.Navigator  initialRouteName="Register" 
       screenOptions={{
        headerStyle: appStyles.headerStyle,
        headerTitleStyle: appStyles.headerTitleStyle,
        headerTitleAlign:'center',
      }}>
        <Stack.Screen name="Register" component={RegisterScreen} options={{ title: 'Register',}}/>
        <Stack.Screen name="Login" component={LoginScreen} options={{ title: 'Login' }} />
        <Stack.Screen name="Home" component={HomeScreen} options={({ navigation }) => ({
          headerTitle: () => (
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 10 }}>
              <TouchableOpacity
                onPress={openModal}
                 >                
                <FontAwesomeIcon
                  icon={faBars}
                  size={20}
                />
              </TouchableOpacity>
              <SideBarModal visible={modalVisible} onClose={closeModal} username={'User'} profileImageUri={'https://campussafetyconference.com/wp-content/uploads/2020/08/iStock-476085198.jpg'} />
              <View style={{ flexDirection: 'row', backgroundColor: '#f0f0f0', borderRadius: 20, alignItems: 'center', paddingHorizontal: 15 , marginLeft: 15, marginRight: 10}}>
                <FontAwesomeIcon icon={faSearch} size={18} style={{ marginRight: 5 }} />
                <TextInput placeholder="Search" placeholderTextColor="gray" style={{ flex: 1, color: 'black', height: 40, marginLeft: 15 }} />
              </View>
            </View>
          ),
          headerStyle: {
            backgroundColor: 'white',
          },
          headerLeft: () => null, // Remove the default back button
        })} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}


export default AppNavigator;
