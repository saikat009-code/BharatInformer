const newsData = [
    {
      id: 1,
      title: 'Karmatech Hachathon',
      details:'Karmatek is an annual Techno Management Festival organized by the Technical Wing of Government College of Engineering and Ceramic Technology',
      date: 'Oct 25, 2023',
      image: require('../../assets/karma.jpg'),
    },
    {
      id: 2,
      title: 'Quiz Competetion',
      details:'Open to all',
      date: 'Oct 24, 2023',
      image: require('../../assets/quiz.jpg'),
    },
    {
        id: 3,
        title: 'Debate Competition',
        details:'Open to all',
        date: 'Oct 24, 2023',
        image: require('../../assets/debate.jpg'),
      },
      {
        id: 4,
        title: 'Tech Fest',
        details:'The annual techno-management fest of Govt. College Of Engineering And Ceramic Technology.',
        date: 'Oct 24, 2023',
        image: require('../../assets/nn.jpg'),
      },
      {
        id: 5,
        title: 'Exam News ',
        details:'Notice for PPR of Papers of Even Semester(B.Tech & M.Tech) of A.S. 2022-23',
        date: 'Oct 25, 2023',
        image: require('../../assets/en.jpg'), // Replace with your image paths
      },
    // Add more news items
  ];
  
  export default newsData;
  