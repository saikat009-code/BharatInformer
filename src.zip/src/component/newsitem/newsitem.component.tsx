import React from 'react';
import { View, Text, Image, StyleSheet, ImageSourcePropType } from 'react-native';

interface NewsItemProps {
    imageSource: ImageSourcePropType;
    title: string;
    details:string;
    date: string;
  }
  
  const NewsItem: React.FC<NewsItemProps> = ({ imageSource, title, details, date }) => {
    return (
      <View style={styles.container}>
        <Image source={imageSource} style={styles.image} />
        <View style={styles.content}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.details}>{details}</Text>
          <Text style={styles.date}>{date}</Text>
        </View>
      </View>
    );
  };

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  image: {
    borderRadius: 10,
    width: 100,
    height: 100,
    marginRight: 10,
  },
  content: {
    flex: 1,
  },
  title: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 5,
    color: 'black'
  },
  details: {
    fontSize: 16,
    marginBottom: 5,
    color: 'black',
    fontFamily: 'Arial',
  },
  date: {
    marginTop: 20,
    color: '#888',
  },
});

export default NewsItem;