import { faPlayCircle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Image, FlatList, StyleSheet } from 'react-native';

interface CarouselItemProps {
  item: {
    id: string;
    imageUrl: string;
    title: string;
  };
}

const CarouselItem: React.FC<CarouselItemProps> = ({ item }) => {
  return (
    <View style={styles.carouselItem}>
      <Image source={{ uri: item.imageUrl }} style={styles.carouselImage} />
      <View style={styles.overlayContainer}>
        <FontAwesomeIcon icon={faPlayCircle}  style={styles.playCircle} size={30} color="white"/>
        <Text style={styles.watchNowText}>Watch Now</Text>
      </View>
    </View>
    
  );
};

interface MyCarouselProps {
  data: Array<{
    id: string;
    imageUrl: string;
    title: string;
  }>;
  autoScrollInterval?: number; // Interval in milliseconds
}

const MyCarousel: React.FC<MyCarouselProps> = ({ data, autoScrollInterval = 3000 }) => {
  const flatListRef = useRef<FlatList<any> | null>(null);
  const [activeIndex, setActiveIndex] = useState<number>(0);

  useEffect(() => {
    const timer = setInterval(() => {
      if (flatListRef.current) {
        const nextIndex = (activeIndex + 1) % data.length;
        flatListRef.current.scrollToIndex({ index: nextIndex, animated: true });
        setActiveIndex(nextIndex);
      }
    }, autoScrollInterval);

    return () => clearInterval(timer);
  }, [activeIndex, data, autoScrollInterval]);

  return (
    <View>
      <FlatList
        ref={flatListRef}
        data={data}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <CarouselItem item={item} />}
      />
      <Text style={styles.paginationText}>
        {`${activeIndex + 1}/${data.length}`}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  carouselItem: {
    width: 400, // Adjust to your item width
    height: 240,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 10, // Add margin between items
  },
  carouselImage: {
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    width: 400,
    height: 160,
    resizeMode: 'cover',
  },

  overlayContainer: {
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
    height: 45,
    width: 400,
    backgroundColor: '#A20000',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paginationText: {
    alignSelf: 'center',
    fontSize: 16,
    color: 'black',
  },
  watchNowText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  playCircle: {
    color: 'white',
    fontSize: 14,
  }
});

export default MyCarousel;
