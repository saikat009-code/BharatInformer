import React, { useEffect } from 'react';
import { Modal, View, Text, TouchableOpacity, StyleSheet, Animated, Image, Easing } from 'react-native';
import sideBarStyles from './SidebaeModal.style';
import { faUser, faCog, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';


interface CustomModalProps {
  visible: boolean;
  onClose: () => void;
  username: string;
  profileImageUri: string;
}


const SideBarModal: React.FC<CustomModalProps> = ({ visible, onClose, username, profileImageUri }) => {

    const modalWidth = 300; // Width of the modal (adjust as needed)

    const modalTranslateX = new Animated.Value(visible ? 0 : -modalWidth);
    const openModal = () => {      
        setTimeout(() => {
          Animated.timing(modalTranslateX, {
            toValue: 0,
            duration: 300, // Adjust the duration as needed
            useNativeDriver: false, // Set to true if using reanimated
          }).start();
        });
      };
  
    const closeModal = () => {
      Animated.timing(modalTranslateX, {
        toValue: -modalWidth,
        duration: 300, // Adjust the duration as needed
        useNativeDriver: false, // Set to true if using reanimated
      }).start(() => onClose());
    };
    useEffect(() => {
        if (visible) {
          openModal();
        } else {
          closeModal();
        }
      }, [visible]);
    

  return ( 
<Modal transparent visible={visible} animationType="none" onRequestClose={closeModal} >
     <TouchableOpacity style={sideBarStyles.modalContainer} activeOpacity={1} >
        <Animated.View style={[sideBarStyles.modalContent, { transform: [{ translateX: modalTranslateX }] }]}>
        <TouchableOpacity  onPress={closeModal}>
         <Text style={sideBarStyles.closeButtonText}>X</Text>
         </TouchableOpacity>
        <View style={sideBarStyles.menuContent}>
          <Image source={{ uri: profileImageUri }} style={sideBarStyles.profileImage} />
          <Text style={sideBarStyles.username}>{username}</Text>
          <TouchableOpacity style={sideBarStyles.menuItem}>
            <FontAwesomeIcon icon={faUser} size={20} style={sideBarStyles.menuIcon} />
            <Text style={sideBarStyles.textColor}>Profile</Text>
          </TouchableOpacity>
          <TouchableOpacity style={sideBarStyles.menuItem}>
            <FontAwesomeIcon icon={faCog} size={20} style={sideBarStyles.menuIcon} />
            <Text  style={sideBarStyles.textColor}>Settings</Text>
          </TouchableOpacity>
          <TouchableOpacity style={sideBarStyles.menuItem} onPress={closeModal}>
            <FontAwesomeIcon icon={faSignOutAlt} size={20} style={sideBarStyles.menuIcon} />
            <Text  style={sideBarStyles.textColor}>Sign Out</Text>
          </TouchableOpacity>
      </View>
        </Animated.View>
      </TouchableOpacity>
    </Modal>
);
};

export default SideBarModal;