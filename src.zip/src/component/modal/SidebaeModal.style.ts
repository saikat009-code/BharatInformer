import { StyleSheet } from "react-native";

const sideBarStyles = StyleSheet.create({
    modalContainer: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        alignItems: 'flex-start',
      },
      modalContent: {
        backgroundColor: '#E6EAEA',
        width: '55%', // Adjust as needed
        height: '100%'
      },
      menuContent: {
        backgroundColor: '#E6EAEA',
        width: '70%', // Adjust the width as needed
        paddingTop: 20,
        paddingLeft: 20,
      },
      profileImage: {
        width: 80,
        height: 80,
        borderRadius: 40,
        alignSelf: 'center',
      },
      username: {
        fontSize: 18,
        fontWeight: 'bold',
        textAlign: 'center',
        marginVertical: 10,
        color:'black'
      },
      menuItem: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 10,
      },
      menuIcon: {
        marginRight: 10,
      },
      closeButtonText: {
        color: 'red', // Change the text color as needed
        fontSize: 18,
        top: 8,
        right: 20,
        fontWeight: 'bold',
        textAlign: 'right'
      },
      textColor: {
        color:'black'
      }
  });

  export default sideBarStyles;
  