import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {FontAwesomeIcon} from '@fortawesome/react-native-fontawesome'
import styles from './register.style';
import { faUser, faLock, faEnvelope, faMobile } from '@fortawesome/free-solid-svg-icons';        
import { StackNavigationProp } from '@react-navigation/stack';
import { Alert } from 'react-native';

type YourStackParamList = {
  Register: undefined;
  Login: undefined;
};


const RegisterScreen = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobileNo] = useState('');
  const [password, setPassword] = useState('');
  const navigation = useNavigation<StackNavigationProp<YourStackParamList, 'Register'>>();
  const handleRegister = () => {
    if (!username || !password || !email) {
      // Display an alert if either field is empty
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }
    console.log('Username:', username);
    console.log('Email:', email);
    console.log('Password:', password);
  };
  const handleLogin = () => {
    navigation.navigate('Login');
  };
  return (
    <View style={styles.container}>
      <Image
        source={require('../../assets/clg.png')} // Use relative path to asset
        style={styles.image}
      />
     <View style={styles.inputContainer}>
      <FontAwesomeIcon icon={faUser} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Username"
          placeholderTextColor = "#999" 
          value={username}
          onChangeText={setUsername}
        />
      </View>
      <View style={styles.inputContainer}>
        <FontAwesomeIcon icon={faEnvelope} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor = "#999" 
          value={email}
          onChangeText={setEmail}
        />
      </View>
      <View style={styles.inputContainer}>
      <FontAwesomeIcon icon={faMobile} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Mobileno"
          placeholderTextColor = "#999" 
          value={mobile}
          onChangeText={setMobileNo}
        />
      </View>
      <View style={styles.inputContainer}>
        <FontAwesomeIcon icon={faLock} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Password"
          placeholderTextColor = "#999" 
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={handleRegister}>
        <Text style={styles.buttonText}>Register</Text>
      </TouchableOpacity>
      <View style={styles.loginSection}>
        <Text style={styles.loginButtonText}>Already a Member? </Text>
        <TouchableOpacity onPress={handleLogin}>
          <Text style={styles.loginButtonText}>Login</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default RegisterScreen;
