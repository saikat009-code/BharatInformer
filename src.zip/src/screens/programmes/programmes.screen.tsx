import React from 'react';
import { View, Text, FlatList } from 'react-native';
import newsData from '../../component/newsitem/NewsData';
import NewsItem from '../../component/newsitem/newsitem.component';

const Programme = () => {
  return (
    <FlatList
    data={newsData}
    renderItem={({ item }) => (
      <NewsItem
        imageSource={item.image}
        title={item.title}
        details={item.details}
        date={item.date}
      />
    )}
    keyExtractor={(item) => item.id.toString()}
  />
  );
};

export default Programme;
