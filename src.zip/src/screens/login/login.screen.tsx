import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {FontAwesomeIcon} from '@fortawesome/react-native-fontawesome'
import styles from './login.style';
import { faUser, faLock } from '@fortawesome/free-solid-svg-icons';        
import { StackNavigationProp } from '@react-navigation/stack';
import { Alert } from 'react-native';

type YourStackParamList = {
    Register: undefined;
    Login: undefined;
    Home: undefined;
  };

const LoginScreen = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigation = useNavigation<StackNavigationProp<YourStackParamList, 'Login'>>();
  const handleRegister = () => {
    navigation.navigate('Register');
  };
  const handleLogin = () => {
    if (!username || !password) {
        // Display an alert if either field is empty
        Alert.alert('Error', 'Please fill in all fields');
        return;
      }
    console.log('Username:', username);
    console.log('Password:', password);
    navigation.navigate('Home');
  };

  return (
    <View style={styles.container}>
      <Image
        source={require('../../assets/login.png')} // Use relative path to asset
        style={styles.image}
      />
     <View style={styles.inputContainer}>
      <FontAwesomeIcon icon={faUser} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Username"
          placeholderTextColor = "#999" 
          value={username}
          onChangeText={setUsername}
        />
      </View>     
      <View style={styles.inputContainer}>
        <FontAwesomeIcon icon={faLock} style={styles.inputIcon} />
        <TextInput
          style={styles.input}
          placeholder="Password"
          placeholderTextColor = "#999" 
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
      <View style={styles.loginSection}>
        <Text style={styles.loginButtonText}>Don't have a Account? </Text>
        <TouchableOpacity onPress={handleRegister}>
          <Text style={styles.loginButtonText}>Register</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default LoginScreen;
