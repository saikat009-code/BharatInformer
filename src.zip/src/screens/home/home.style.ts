import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    title: {
      fontSize: 20,
      marginBottom: 20,
    },
    tabBar: {
      backgroundColor: 'white', // Background color of the tab bar
    },
    tabLabel: {
      fontWeight: 'bold',      // Styling for the tab label
    },
  });

  

export default styles;