import React, { useRef } from 'react';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import styles from './home.style';
import Programme from '../programmes/programmes.screen';
import News from '../news/news.screen';
import LiveStreame from '../livestreame/livestreame.screen';
import Video from '../video/video.screen';

const Tab = createMaterialTopTabNavigator();

const HomeScreen = () => { 

  return (
    <Tab.Navigator
    screenOptions={{
      tabBarActiveTintColor: 'blue',      // Color of the active tab label and icon
      tabBarInactiveTintColor: 'gray',    // Color of the inactive tab label and icon
      tabBarIndicatorStyle: {
        backgroundColor: 'green',   // Color of the tab indicator
      },
      tabBarLabelStyle: {
        fontWeight: 'bold',         // Styling for the tab label
      },
      tabBarStyle: {
        backgroundColor: 'white',   // Background color of the tab bar
      },
    }}>
    <Tab.Screen name="College Program" component={Programme} />
    <Tab.Screen name="College News" component={News} />
    <Tab.Screen name="LiveStreme" component={LiveStreame} />

    {/* Add other tab screens here */}
   </Tab.Navigator>

  );
};

export default HomeScreen;