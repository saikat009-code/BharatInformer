import React from 'react';
import { View, Text, StyleSheet, FlatList, Image } from 'react-native';
import Carousel from '../../component/carousel/Carousel';
import { faAngleRight, faCircle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { ScrollView } from 'react-native-gesture-handler';

const LiveStreame = () => {
  const dailyNewsUpdate = [
    {
      id: '1',
      imageUrl: 'https://static.tnn.in/thumb/msid-103399714,updatedat-1693919152917,width-1280,height-720,resizemode-75/103399714.jpg',
      title: 'Video 1',
    },
    {
      id: '2',
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlS2MyP82wFMKpr7e1CxfyAoqgDRx0Bg0seg&usqp=CAU',
      title: 'Video 2',
    },
    {
      id: '3',
      imageUrl: 'https://static.toiimg.com/thumb/msid-74014434,width-400,resizemode-4/74014434.jpg',
      title: 'Video 3',
    },
    // Add more carousel items as needed
  ];
  const topStories = [
    {
      id: '1',
      imageUrl: 'https://resize.indiatvnews.com/en/resize/newbucket/400_-/2023/08/top-10-6-1693197370.jpg',
      title: 'Top 10',
    },
    {
      id: '2',
      imageUrl: 'https://s01.sgp1.digitaloceanspaces.com/large/861680-69419-aiyxpxhxen-1511343672.jpg',
      title: 'Morning HeadLines',
    },
    {
      id: '3',
      imageUrl: 'https://static.toiimg.com/thumb/msid-74014434,width-400,resizemode-4/74014434.jpg',
      title: 'Video 3',
    },
    // Add more carousel items as needed
  ];

  return (
    <ScrollView>
      <Carousel data={dailyNewsUpdate} />
      <View style={styles.dailyNewsContainer}>
      <Text style={styles.dailyNewsUpdate}>Daily News Update</Text>
      <FontAwesomeIcon size={18} icon={faAngleRight } style={styles.faAngleRight} />    
      </View>
      <View>
      <FlatList
        data={dailyNewsUpdate}
        horizontal={true}
        pagingEnabled={true}
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.cardContainer}>
            <Image source={{ uri: item.imageUrl }} style={styles.newsImage} />      
            <View style={styles.titleContainer}>
              <FontAwesomeIcon icon={faCircle} size={10} style={styles.faCircle} />
              <Text style={styles.dailyNewsTitle}>{item.title}</Text>
            </View>   
          </View>
        )}
      />
      </View>
      <View style={styles.dailyNewsContainer}>
      <Text style={styles.dailyNewsUpdate}>Top Stories</Text>
      <FontAwesomeIcon size={18} icon={faAngleRight } style={styles.faAngleRight} />    
      </View>
      <View>
      <FlatList
        data={topStories}
        horizontal={true}
        pagingEnabled={true}
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.cardContainer}>
            <Image source={{ uri: item.imageUrl }} style={styles.newsImage} />      
            <View style={styles.titleContainer}>
              <FontAwesomeIcon icon={faCircle} size={10} style={styles.faCircle} />
              <Text style={styles.dailyNewsTitle}>{item.title}</Text>
            </View>   
          </View>
        )}
      />
      </View>
     
    </ScrollView>
  );
};

export default LiveStreame;

const styles = StyleSheet.create({
  dailyNewsContainer : {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 7,
  },
  dailyNewsUpdate : {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
    left: 12,
    marginBottom: 3,
  },
  faAngleRight : {
    color : 'gray',
    marginRight: 13
  },
  cardContainer: {
    backgroundColor: '#A20000',
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
    margin: 5,
    height: 120,
    width: 170,
    marginHorizontal: 5,
    marginLeft: 12
  },
  newsImage: {
    width: '100%',
    height: '85%',
    borderRadius: 15,
  },
  faCircle : {
     color : 'red'
  },
  dailyNewsTitle : {
    fontSize: 15,
    color: 'white',
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 10,
},
});
