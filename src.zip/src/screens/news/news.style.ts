import { StatusBar, StyleSheet } from 'react-native';

const newsStyles = StyleSheet.create({
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    left: 12,
    marginBottom: 5,
  },
  container: {
    flex: 1,
    padding: 8,
  },
  cardContainer: {
    backgroundColor: 'white',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
    margin: 8,
    height: 200,
    width: 300,
  },
  newsImage: {
    width: '100%',
    height: '65%',
    borderRadius: 15,
  },
  newsInfoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    top: 10,
    justifyContent: 'space-evenly',
},
menuIcon: {
  color:'#E3670B',
},
  trending: {
    fontSize: 16,
    color: 'black',
    marginRight: 100
  },
  date: {
    fontSize: 14,
    color: 'gray',
  },
  newsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    margin: 10,
    color: 'black',
  },
  exploreContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 7
  },
  exploreItem: {
    marginHorizontal: 8,
    alignItems: 'center',
  },
  exploreImage: {
    marginTop: 7,
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  exploreTitle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  seeMore: {
    color: 'gray'
  },
  titleOnImage: {
    left: 0,
    right: 0,
    textAlign: 'center', // Optional background color for better visibility
    color: 'blue', // Text color
  },
  exploreDetailsContainerMain: {
    flex: 1,
    marginTop: 5
  },
  exploreDetailsContainerChild: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 2,
    margin: 8,
    height: 100,
    width: 370,
  },
  exploreDetailsTitle: {
    top: 5,
    fontSize: 16,
    color: 'black',
  },
  exploreInfoContainer: {
    alignItems: 'flex-start',
    top: 15,
    justifyContent: 'space-evenly',
  },
  leftColumn: {
    top: 5,
    left: 8,
    flex: 1, // Occupy 1/2 of the horizontal space
 // Add spacing between columns
  },
  rightColumn: {
    flex: 1, // Occupy 1/2 of the horizontal space
    alignItems:'flex-end'
  },
  exploreImageDetails : {
    width: '95%',
    height: '100%',
    borderRadius: 15,
  },
  exploreDate : {
    fontSize: 12,
    color: 'gray',
  },
  exploreType : {
    fontSize: 12,
    color: 'gray',
  },
  titleTypeContainer : {
    flexDirection: 'row', // Place title and date side by side
    alignItems: 'center',
    paddingRight: 10,
    justifyContent: 'space-between'
  }
});

export default newsStyles;
