import React from 'react';
import { View, Text, Image, FlatList } from 'react-native';
import newsStyles from './news.style';
import { faFire } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';

const News = () => {
  const hottestNews = [
    {
      id: '1',
      imageUrl:
        'https://gcect.ac.in/wp-content/uploads/2023/04/GCECT-GATE-2023.jpeg',
      trending: 'Trending #1',
      date: '1 Day Ago',
      title: 'Gate Qualified Students',
    },
    {
      id: '2',
      imageUrl:
        'https://www.freshersvoice.com/wp-content/uploads/2022/06/TCS-NQT-.png',
      trending: 'Trending #2',
      date: '2 Days Ago',
      title: 'TCS NQT Examination',
    },
    {
      id: '3',
      imageUrl:
        'https://images.collegedunia.com/public/college_data/images/appImage/1488627169c.jpg',
      trending: 'Trending #3',
      date: '3 Days Ago',
      title: 'New Addmition for B Tech',
    },
    // Add more data items as needed
  ];
  const expoloreItems = [
    {
      id: '1',
      imageUrl:
        'https://static.toiimg.com/thumb/msid-74014434,width-400,resizemode-4/74014434.jpg',
      title: 'Big sports events today ',
      type: 'Sports',
      date: 'Today, 10.41 AM',
    },
    {
      id: '2',
      imageUrl:
        'https://c6k7e2u7.rocketcdn.me/wp-content/uploads/2016/01/FreeGreatPicture.com-32253-technology-news.jpg',
      title: 'The Future of Business Technology',
      type: 'Technology',
      date: 'Yesterday, 10.41 AM',
    },
    {
      id: '3',
      imageUrl:
        'https://static.tnn.in/thumb/msid-103399714,updatedat-1693919152917,width-1280,height-720,resizemode-75/103399714.jpg',
      title: 'India That Is Bharat? | Bharat Vs India Sparks Political Buzz Amid G20 ',
      type: 'Political',
      date: '02/09/23, 11.45 PM',
    },
    {
      id: '4',
      imageUrl:
        'https://educationtoday.co/blogs/wp-content/uploads/2021/05/Education-Today-2nd-page-1024x837.jpg',
      title: 'Education News India | 26-05-2021 | Education News Network',
      type: 'Education',
      date: '01/09/23, 03.45 PM',
    },
    // Add more data items as needed
  ];

  return (
    <View style={newsStyles.container}>
      <Text style={newsStyles.title}>Hottest News</Text>
      <View >
      <FlatList
        data={hottestNews}
        horizontal={true}
        pagingEnabled={true}
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={newsStyles.cardContainer}>
            <Image source={{ uri: item.imageUrl }} style={newsStyles.newsImage} />
            <View style={newsStyles.newsInfoContainer}>
              <FontAwesomeIcon icon={faFire} size={20} style={newsStyles.menuIcon} />
              <Text style={newsStyles.trending}>{item.trending}</Text>
              <Text style={newsStyles.date}>{item.date}</Text>
            </View>
            <Text style={newsStyles.newsTitle}>{item.title}</Text>
          </View>
        )}
      />
      </View>
      {/* Explore Section */}
      <View style={newsStyles.exploreContainer}>
      <Text style={newsStyles.title}>Explore</Text>
          <Text  style={newsStyles.seeMore}>See More</Text>       
      </View>
      <View>
      <FlatList 
        data={expoloreItems}
        horizontal={true}
        pagingEnabled={true}
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={newsStyles.exploreItem}>
            <Image source={{ uri: item.imageUrl }} style={newsStyles.exploreImage} />
            <Text style={newsStyles.titleOnImage}>{item.type}</Text>
          </View>
        )}
      /> 
      </View>
    <View style={newsStyles.exploreDetailsContainerMain}>
    <FlatList
        data={expoloreItems}   
        horizontal={false}
        pagingEnabled={true} 
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={newsStyles.exploreDetailsContainerChild}>          
                {/* Left column for title and date */}
            <View style={newsStyles.leftColumn}>
              <View style={newsStyles.titleTypeContainer}>
                <Text style={newsStyles.exploreType}>{item.type}</Text>
                <Text style={newsStyles.exploreDate}>{item.date}</Text>  
              </View>    
              <Text style={newsStyles.exploreDetailsTitle}>{item.title}</Text>      
            </View>

            {/* Right column for image */}
            <View style={newsStyles.rightColumn}>
              <Image source={{ uri: item.imageUrl }} style={newsStyles.exploreImageDetails} />
            </View>
          </View>
        )}
      />
    </View>  
    </View>
  );
};

export default News;
