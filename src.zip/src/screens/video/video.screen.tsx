import React from 'react';
import { View, Text } from 'react-native';

const Video = () => {
  return (
    <View>
      <Text>Tab 4 Content</Text>
    </View>
  );
};

export default Video;

